$(function() {
		$( ".date" ).datepicker({
			changeMonth: true,
			changeYear: true,
			dateFormat: "yy-mm-dd",
			yearRange: "2010:2020"
		});
	});