<?php
//@ini_set('display_errors', 'off');
mysql_connect("localhost","root","1");
mysql_select_db("personalia");

$host="localhost";
$user="root";
$pass="1";
$db="personalia";

?>